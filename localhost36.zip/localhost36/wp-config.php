<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'mrdiscount' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '6MxkX5QfXG:G!|4Y~W6)-yV>R?I6C>q6nw)ii*2sJN$-E2,7KEr/b.%7T|2/#uMH' );
define( 'SECURE_AUTH_KEY',  'Hd h*7ym.FP{S_jqzd}dTWt_x.Msh=f)Ld{3I-M#3b_r=Qr_IqX(E_?U}x7f/!<:' );
define( 'LOGGED_IN_KEY',    '|=s-*Ju|~WdfX%Toagmd&n5FnQ3^L{yc./jj1l*n+v@{%(i|E/ZI32}Tr8dt],I-' );
define( 'NONCE_KEY',        'U&.F7yH$II*~(fpC6!o~juC.&tW36#zv@-r0fcfB(UjyDM1P2kP(U,EDmp@s`[fI' );
define( 'AUTH_SALT',        ')9ils,aT(!m3N_Ya+{Vf>Mn@@dl:1Y8ZsBV-{5~V4g5Q5v6/`cyn]23n+SCA*xS,' );
define( 'SECURE_AUTH_SALT', 'E$MkgdpAfd5`=2*r5>C >X+~V/8K<F*HW;uu&05*I?2^6x4TK;DR{A~Z!]kB~P1]' );
define( 'LOGGED_IN_SALT',   'PCvL&6b=9$h[0ye.#9L_71[&00h7Z@O9Hcv?aTk%szXknPmiL#[JNF}=i=Z<No)[' );
define( 'NONCE_SALT',       'v^MS6+|o=qn}^gn7NUVCz1@`B7@ZM65F5^^:}Vt{#]+{jqKt.SN2xPNQnIMm!)./' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );

set_time_limit(300);